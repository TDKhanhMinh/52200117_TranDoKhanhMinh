package com.example.Lab07;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab07ApplicationTests {

	@Test
	void contextLoads() {
	}

}
