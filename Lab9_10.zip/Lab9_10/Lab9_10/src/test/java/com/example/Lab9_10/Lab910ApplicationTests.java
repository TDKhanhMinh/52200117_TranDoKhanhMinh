package com.example.Lab9_10;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab910ApplicationTests {

	@Test
	void contextLoads() {
	}

}
