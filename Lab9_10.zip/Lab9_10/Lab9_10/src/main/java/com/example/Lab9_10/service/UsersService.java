package com.example.Lab9_10.service;

import org.springframework.stereotype.Service;

@Service
public class UsersService {
}
